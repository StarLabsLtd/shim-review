# Signed UKIs

Use the unmodified ukify and systemd-measure pinned in `upstream.lock`.
The stub hash is from the source-pinned Vale systemd-boot-efi package; update
it when that package changes. The SBAT hash binds the Vale generation policy.
Preparation checks the copied ukify. DAVE and recovery builders check all
four signing inputs before invoking native tools.

Normal Install and Normal recovery have Secure Boot signatures and no TPM
policy authority. Installed DAVE embeds the ROOT public key (`pcr-policy`):
ROOT signs `enter-initrd` and the required runtime phases. The separate HIB
key (`pcr-initrd`) signs `enter-initrd`. Recovery uses its own key and
`sysinit:ready`. Each image has one purpose and stock zero-origin PCR11.
The verifier checks the exact command line, authorities, phases and signatures.
Literal PCR7 is bound by enrollment, not by the PCR11 signature entries.

The old multiprofile ukify patch and prefixed PCR11 adapter are retired
experiments (source retained in `out/retired-pcr-signing-source-20261003`).
Neither participates in current signing. Generic ROOT unlock
and maintenance require separate native TPM evidence. HIB additionally needs
firmware's monotonic counter and live handoff; UKI verification alone does
not close that integration or qualify an installer for release.
