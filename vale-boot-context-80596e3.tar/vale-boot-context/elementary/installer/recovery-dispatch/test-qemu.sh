#!/usr/bin/env bash
set -euo pipefail
source_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
output=$(realpath "${1:?usage: test-qemu.sh BUILD_OUTPUT_DIRECTORY}")
sdk=$(cat "${output}/sdk-image-id")
podman run --rm -i --pull=never --network none --read-only --cap-drop all \
    --security-opt no-new-privileges --tmpfs /tmp:rw,nosuid,nodev \
    -v "${source_dir}:/source:ro" -v "${output}:/output:rw" "${sdk}" bash -s <<'BUILD'
set -euo pipefail
efi=/build/gnu-efi
for leaf in Normal Dave; do
    defines=()
    if [[ $leaf == Dave ]]; then defines=(-DLEAF_DAVE); fi
    gcc -I "$efi/inc" -I "$efi/inc/x86_64" -DGNU_EFI_USE_MS_ABI "${defines[@]}" \
        -Wall -Wextra -Werror -O2 -fpic -ffreestanding -fshort-wchar -mno-red-zone \
        -fno-stack-protector -fno-asynchronous-unwind-tables \
        -c /source/test-leaf.c -o "/output/$leaf.o"
    ld -nostdlib -znocombreloc --build-id=none -shared -Bsymbolic \
        -T "$efi/gnuefi/elf_x86_64_efi.lds" "$efi/x86_64/gnuefi/crt0-efi-x86_64.o" \
        "/output/$leaf.o" -L "$efi/x86_64/gnuefi" -lgnuefi -o "/output/$leaf.so"
    objcopy -j .text -j .data -j .dynamic -j .dynsym -j .rela -j .reloc \
        --strip-all -O pei-x86-64 --subsystem=10 "/output/$leaf.so" "/output/$leaf.efi"
done
BUILD
scratch=$(mktemp -d "${output}/qemu.XXXXXX")
trap 'rm -rf -- "${scratch}"' EXIT
truncate -s 16M "${scratch}/esp.img"
mkfs.vfat "${scratch}/esp.img" >/dev/null
mmd -i "${scratch}/esp.img" ::/EFI ::/EFI/BOOT ::/EFI/Vale
mcopy -i "${scratch}/esp.img" "${output}/recovery-dispatch.efi" ::/EFI/BOOT/BOOTX64.EFI
mcopy -i "${scratch}/esp.img" "${output}/Normal.efi" "${output}/Dave.efi" ::/EFI/Vale/
for vendor in DAVE dave DAVE-extra 'EDK II'; do
    cp /usr/share/OVMF/OVMF_VARS_4M.fd "${scratch}/vars.fd"
    log="${output}/qemu-${vendor// /_}.log"
    status=0
    timeout 40s qemu-system-x86_64 -machine q35,accel=tcg -m 256 -nodefaults \
        -drive if=pflash,format=raw,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.fd \
        -drive "if=pflash,format=raw,file=${scratch}/vars.fd" \
        -drive "if=none,id=esp,format=raw,file=${scratch}/esp.img,readonly=on" \
        -device virtio-blk-pci,drive=esp -smbios "type=0,vendor=${vendor}" \
        -device isa-debug-exit,iobase=0xf4,iosize=0x04 \
        -debugcon "file:${log}" -global isa-debugcon.iobase=0xe9 \
        -display none -serial none -monitor none -nic none -no-reboot || status=$?
    [[ ${status} == 33 ]]
    expected=NORMAL
    if [[ ${vendor} == DAVE ]]; then expected=DAVE; fi
    grep -Fx "DISPATCH:${expected}" "${log}"
done
printf '%s\n' 'PASS: OVMF boots selected the expected same-media leaf for all four BIOS vendors'
