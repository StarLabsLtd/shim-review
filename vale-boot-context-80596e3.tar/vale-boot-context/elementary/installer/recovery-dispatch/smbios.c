/* SPDX-License-Identifier: MIT */
#include "smbios.h"

bool smbios_is_dave(const uint8_t *table, size_t size, uint16_t count)
{
    bool found = false, dave = false;
    size_t offset = 0;
    unsigned records = 0;

    while (offset < size) {
        const uint8_t *record = table + offset;
        size_t remaining = size - offset;
        if (remaining < 4 || record[1] < 4 || record[1] > remaining)
            return false;

        size_t end = record[1];
        while (end + 1 < remaining && (record[end] || record[end + 1]))
            end++;
        if (end + 1 >= remaining)
            return false;

        if (record[0] == 0) {
            if (found || record[1] < 0x12 || record[4] == 0)
                return false;
            found = true;
            size_t start = record[1];
            unsigned index = 1;
            while (start < end && index < record[4]) {
                while (start < end && record[start])
                    start++;
                start++;
                index++;
            }
            if (start >= end || index != record[4])
                return false;
            size_t length = 0;
            while (start + length < end && record[start + length])
                length++;
            dave = length == 4 && record[start] == 'D' && record[start + 1] == 'A' &&
                   record[start + 2] == 'V' && record[start + 3] == 'E';
        }

        offset += end + 2;
        records++;
        if (record[0] == 127) {
            if (record[1] != 4 || end != 4)
                return false;
            return dave && (!count || (records == count && offset == size));
        }
        if (count && records == count)
            return dave && offset == size;
    }
    return false;
}
