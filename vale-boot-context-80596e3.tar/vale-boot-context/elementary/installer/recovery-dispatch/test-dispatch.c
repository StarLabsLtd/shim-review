/* SPDX-License-Identifier: MIT */
#define _GNU_SOURCE
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

#include <efi.h>
#include <efilib.h>
#include "smbios.h"

EFI_STATUS efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *system);

EFI_BOOT_SERVICES *BS;
EFI_GUID LoadedImageProtocol = EFI_LOADED_IMAGE_PROTOCOL_GUID;
EFI_GUID SMBIOSTableGuid = SMBIOS_TABLE_GUID;
EFI_GUID SMBIOS3TableGuid = SMBIOS3_TABLE_GUID;

static EFI_HANDLE parent = (void *)1, device = (void *)2, child = (void *)3;
static EFI_LOADED_IMAGE loaded;
static EFI_MEMORY_DESCRIPTOR memory;
static SMBIOS_STRUCTURE_TABLE *entry2;
static SMBIOS3_STRUCTURE_TABLE *entry3;
static UINT8 *region, *table;
static bool have2, have3, no_map, no_path, no_device_path;
static EFI_STATUS load_status, start_status, handle_status;
static unsigned loads, starts, unloads, frees;
static CHAR16 selected[64];

VOID InitializeLib(EFI_HANDLE image, EFI_SYSTEM_TABLE *system)
{
    assert(image == parent);
    BS = system->BootServices;
}

EFI_STATUS LibGetSystemConfigurationTable(EFI_GUID *guid, VOID **out)
{
    if (guid == &SMBIOS3TableGuid && have3) {
        *out = entry3;
        return EFI_SUCCESS;
    }
    if (guid == &SMBIOSTableGuid && have2) {
        *out = entry2;
        return EFI_SUCCESS;
    }
    return EFI_NOT_FOUND;
}

EFI_MEMORY_DESCRIPTOR *LibMemoryMap(UINTN *entries, UINTN *key, UINTN *stride, UINT32 *version)
{
    *entries = 1;
    *key = 0;
    *stride = sizeof(memory);
    *version = EFI_MEMORY_DESCRIPTOR_VERSION;
    if (no_map)
        return NULL;
    EFI_MEMORY_DESCRIPTOR *map = malloc(sizeof(memory));
    assert(map);
    *map = memory;
    return map;
}

VOID FreePool(VOID *data)
{
    assert(data);
    frees++;
    free(data);
}

INTN CompareMem(const VOID *a, const VOID *b, UINTN size)
{
    return memcmp(a, b, size);
}

UINTN EFIAPI Print(const CHAR16 *format, ...)
{
    (void)format;
    return 0;
}

EFI_DEVICE_PATH *FileDevicePath(EFI_HANDLE handle, CHAR16 *path)
{
    assert(handle == device);
    for (size_t i = 0; i < sizeof(selected) / sizeof(selected[0]); i++) {
        selected[i] = path[i];
        if (!path[i])
            break;
    }
    return no_path ? NULL : calloc(1, sizeof(EFI_DEVICE_PATH));
}

EFI_DEVICE_PATH *DevicePathFromHandle(EFI_HANDLE handle)
{
    static EFI_DEVICE_PATH path;
    assert(handle == device);
    return no_device_path ? NULL : &path;
}

static EFI_STATUS EFIAPI handle_protocol(EFI_HANDLE image, EFI_GUID *guid, VOID **out)
{
    assert(image == parent && guid == &LoadedImageProtocol);
    *out = &loaded;
    return handle_status;
}

static EFI_STATUS EFIAPI load_image(BOOLEAN policy, EFI_HANDLE image, EFI_DEVICE_PATH *path,
                                   VOID *buffer, UINTN size, EFI_HANDLE *out)
{
    assert(!policy && image == parent && path && !buffer && !size);
    loads++;
    *out = load_status == EFI_NOT_FOUND ? NULL : child;
    return load_status;
}

static EFI_STATUS EFIAPI start_image(EFI_HANDLE image, UINTN *size, CHAR16 **data)
{
    assert(image == child && !size && !data);
    starts++;
    return start_status;
}

static EFI_STATUS EFIAPI unload_image(EFI_HANDLE image)
{
    assert(image == child);
    unloads++;
    return EFI_SUCCESS;
}

static EFI_BOOT_SERVICES services = {
    .HandleProtocol = handle_protocol,
    .LoadImage = load_image,
    .StartImage = start_image,
    .UnloadImage = unload_image,
};
static EFI_SYSTEM_TABLE system_table = {.BootServices = &services};

static void checksum(UINT8 *data, size_t size, size_t offset)
{
    data[offset] = 0;
    UINT8 sum = 0;
    for (size_t i = 0; i < size; i++)
        sum += data[i];
    data[offset] = -sum;
}

static void seal_entries(size_t size)
{
    entry2->TableLength = size;
    checksum((UINT8 *)entry2 + 16, 15, 5);
    checksum((UINT8 *)entry2, sizeof(*entry2), 4);
    entry3->TableMaximumSize = size;
    checksum((UINT8 *)entry3, sizeof(*entry3), 5);
}

static size_t reset(const char *vendor)
{
    memset(region, 0, 4096);
    table[0] = 0;
    table[1] = 0x12;
    table[4] = 1;
    size_t length = strlen(vendor);
    memcpy(table + 0x12, vendor, length);
    size_t end = 0x12 + length + 2;
    table[end] = 127;
    table[end + 1] = 4;
    memcpy(entry2->AnchorString, "_SM_", 4);
    memcpy(entry2->IntermediateAnchorString, "_DMI_", 5);
    entry2->EntryPointLength = sizeof(*entry2);
    entry2->MajorVersion = 2;
    entry2->TableAddress = (UINTN)table;
    entry2->NumberOfSmbiosStructures = 2;
    memcpy(entry3->AnchorString, "_SM3_", 5);
    entry3->EntryPointLength = sizeof(*entry3);
    entry3->MajorVersion = 3;
    entry3->EntryPointRevision = 1;
    entry3->TableAddress = (UINTN)table;
    seal_entries(end + 6);
    memory = (EFI_MEMORY_DESCRIPTOR){
        .Type = EfiRuntimeServicesData, .PhysicalStart = (UINTN)region, .NumberOfPages = 1,
    };
    loaded.DeviceHandle = device;
    have2 = have3 = true;
    no_map = no_path = no_device_path = false;
    loads = starts = unloads = frees = 0;
    load_status = handle_status = EFI_SUCCESS;
    start_status = EFI_ABORTED;
    memset(selected, 0, sizeof(selected));
    return end + 6;
}

static void expect_target(bool dave)
{
    assert(efi_main(parent, &system_table) == EFI_ABORTED);
    const CHAR16 *expected = dave ? L"\\EFI\\Vale\\Dave.efi" : L"\\EFI\\Vale\\Normal.efi";
    assert(memcmp(selected, expected, (dave ? 19 : 21) * sizeof(CHAR16)) == 0);
    assert(loads == 1 && starts == 1 && unloads == 1);
}

int main(void)
{
    /* SMBIOS 2 addresses are 32-bit even when the dispatcher is x86-64. */
    region = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_32BIT, -1, 0);
    assert(region != MAP_FAILED);
    entry2 = (void *)region;
    entry3 = (void *)(region + 64);
    table = region + 128;

    reset("DAVE"); expect_target(true);
    reset("DAVE"); have3 = false; expect_target(true);
    const char *others[] = {"dave", "DAVE ", "DAVE-extra", "EDK II", ""};
    for (size_t i = 0; i < sizeof(others) / sizeof(others[0]); i++) {
        reset(others[i]); expect_target(false);
    }
    reset("DAVE"); have2 = have3 = false; expect_target(false);
    reset("DAVE"); no_map = true; expect_target(false);
    reset("DAVE"); entry3->EntryPointStructureChecksum++; expect_target(false);
    reset("DAVE"); have3 = false; entry2->IntermediateChecksum++; expect_target(false);
    reset("DAVE"); entry3->EntryPointLength--; expect_target(false);
    reset("DAVE"); entry3->TableAddress = UINT64_MAX - 3;
    seal_entries(30); expect_target(false);
    reset("DAVE"); seal_entries(4096); expect_target(false);
    reset("DAVE"); memory.Attribute = EFI_MEMORY_RP; expect_target(false);
    reset("DAVE"); memory.Type = EfiMemoryMappedIO; expect_target(false);
    reset("DAVE"); entry3 = (void *)(region + 4090); expect_target(false);
    entry3 = (void *)(region + 64);

    size_t size = reset("DAVE");
    for (size_t i = 0; i < size; i++)
        assert(!smbios_is_dave(table, i, 0));
    table[1] = 3; assert(!smbios_is_dave(table, size, 0));
    reset("DAVE"); table[4] = 2; expect_target(false);
    reset("DAVE"); table[4] = 0; expect_target(false);
    reset("DAVE"); table[1] = 0xff; expect_target(false);
    reset("DAVE"); table[24] = 0; expect_target(false); /* Duplicate type 0. */
    reset("DAVE"); table[25] = 3; expect_target(false); /* Malformed end record. */
    reset("DAVE"); memset(table + 18, 'X', 12); expect_target(false);
    reset("DAVE"); have3 = false; entry2->NumberOfSmbiosStructures = 3;
    seal_entries(30); expect_target(false);
    reset("DAVE"); table[0] = 1; expect_target(false); /* Not BIOS vendor. */

    /* A later indexed string, following a preceding non-BIOS record. */
    reset("DAVE");
    for (size_t i = 30; i > 0; i--)
        table[i + 5] = table[i - 1];
    memset(table, 0, 6); table[0] = 1; table[1] = 4;
    memmove(table + 26, table + 24, 12);
    table[24] = 'x'; table[25] = 0; table[10] = 2;
    seal_entries(38); expect_target(true);

    reset("DAVE"); load_status = EFI_SECURITY_VIOLATION;
    assert(efi_main(parent, &system_table) == EFI_SECURITY_VIOLATION);
    assert(loads == 1 && starts == 0 && unloads == 1 && frees == 2);
    reset("DAVE"); load_status = EFI_NOT_FOUND;
    assert(efi_main(parent, &system_table) == EFI_NOT_FOUND);
    assert(loads == 1 && starts == 0 && unloads == 0 && frees == 2);
    reset("DAVE"); no_path = true;
    assert(efi_main(parent, &system_table) == EFI_OUT_OF_RESOURCES);
    assert(loads == 0 && frees == 1);
    reset("DAVE"); handle_status = EFI_UNSUPPORTED;
    assert(efi_main(parent, &system_table) == EFI_UNSUPPORTED);
    assert(loads == 0 && frees == 0);
    reset("DAVE"); no_device_path = true;
    assert(efi_main(parent, &system_table) == EFI_NOT_FOUND);
    assert(loads == 0 && frees == 0);

    /* Guard-page inputs catch reads beyond a declared table extent. */
    UINT8 *guard = mmap(NULL, 8192, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    assert(guard != MAP_FAILED && mprotect(guard + 4096, 4096, PROT_NONE) == 0);
    reset("DAVE");
    for (size_t i = 1; i <= 30; i++) {
        memcpy(guard + 4096 - i, table, i);
        assert(smbios_is_dave(guard + 4096 - i, i, 0) == (i == 30));
    }
    munmap(guard, 8192);
    munmap(region, 4096);
    puts("PASS: SMBIOS 2/3 selection, malformed bounds, same-device chainloading and failure cleanup");
    return 0;
}
