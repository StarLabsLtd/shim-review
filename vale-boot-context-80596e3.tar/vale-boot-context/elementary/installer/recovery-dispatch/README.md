# Recovery dispatcher

This x86-64 EFI application loads `\EFI\Vale\Dave.efi` only when the SMBIOS
type 0 BIOS vendor is exactly `DAVE`. Otherwise it loads
`\EFI\Vale\Normal.efi`. Both paths are relative to the dispatcher's loaded
image device. Selection has no menu, readiness checks or persistent settings.
The native installer UI must use the same exact BIOS-vendor rule.

SMBIOS 3 takes precedence over SMBIOS 2. Missing or malformed tables select
Normal, including a malformed SMBIOS 3 entry when SMBIOS 2 is also present.
Entry checksums, mapped memory extents, formatted records and terminated string
sets are checked before selection. Tables larger than 16 MiB are rejected to
bound parsing work. A single type 0 record is required; SMBIOS 2 must exhaust its
declared record count and length, and SMBIOS 3 must reach its end-of-table record.

`LoadImage` and `StartImage` leave image authentication to firmware. A failure
loading the selected image is returned without trying another image or device.
The application does not access passwords, TPM protocols or boot variables.

Build with the already cached `localhost/vale-shim:16.1` SDK:

```sh
scripts/build-recovery-dispatch.sh out/recovery-dispatch
elementary/installer/recovery-dispatch/test-qemu.sh out/recovery-dispatch
```

The build runs the parser and boot-service tests under ASan/UBSan, then links
GNU-EFI and the SDK's accompanying string library. It emits an unsigned,
NX-compatible PE application with SBAT. The image assembly lane signs that PE
and supplies the signed result as `VALE_RECOVERY_DISPATCH`; this build has no
access to signing keys. `sdk-image-id` records the resolved SDK image.

The optional QEMU test uses disposable OVMF variable storage and unsigned leaf
fixtures to verify real EFI execution and exact vendor routing. Its debug-port
leaf applications are test artifacts, not recovery images or Secure Boot tests.
