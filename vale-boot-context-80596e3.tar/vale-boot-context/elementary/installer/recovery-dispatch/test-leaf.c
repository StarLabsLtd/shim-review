/* SPDX-License-Identifier: MIT */
/* Disposable QEMU leaf: report which path ran, then exit via isa-debug-exit. */
#include <efi.h>

EFI_STATUS efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *system)
{
    (void)image;
    (void)system;
#ifdef LEAF_DAVE
    const char *message = "DISPATCH:DAVE\n";
#else
    const char *message = "DISPATCH:NORMAL\n";
#endif
    for (const char *p = message; *p; p++)
        __asm__ volatile("outb %0, %1" : : "a"(*p), "Nd"((unsigned short)0xe9));
    __asm__ volatile("outl %0, %1" : : "a"(0x10), "Nd"((unsigned short)0xf4));
    return EFI_ABORTED;
}
