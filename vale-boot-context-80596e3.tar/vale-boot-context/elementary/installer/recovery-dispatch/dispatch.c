/* SPDX-License-Identifier: MIT */
#include <efi.h>
#include <efilib.h>

#include "smbios.h"

static const char sbat[] __attribute__((section(".sbat"), used, aligned(4096))) =
    "sbat,1,SBAT Version,sbat,1,https://github.com/rhboot/shim/blob/main/SBAT.md\n"
    "vale-recovery-dispatch,1,Star Labs,vale-recovery-dispatch,1,https://starlabs.systems\n";

/* Bound firmware-provided sizes as well as every individual record/string. */
#define MAX_SMBIOS_SIZE (16 * 1024 * 1024)

static bool readable_range(const EFI_MEMORY_DESCRIPTOR *map, UINTN entries,
                           UINTN stride, UINT64 address, UINT64 size)
{
    if (!address || !size || address > UINTPTR_MAX || size > UINTPTR_MAX - address ||
        stride < sizeof(*map))
        return false;

    for (UINTN i = 0; i < entries; i++) {
        const EFI_MEMORY_DESCRIPTOR *entry = (const void *)((const UINT8 *)map + i * stride);
        if (entry->Attribute & EFI_MEMORY_RP)
            continue;
        switch (entry->Type) {
        case EfiReservedMemoryType: /* SMBIOS entry points may use reserved memory. */
        case EfiLoaderCode:
        case EfiLoaderData:
        case EfiBootServicesCode:
        case EfiBootServicesData:
        case EfiRuntimeServicesCode:
        case EfiRuntimeServicesData:
        case EfiACPIReclaimMemory:
        case EfiACPIMemoryNVS:
            break;
        default:
            continue;
        }
        if (entry->NumberOfPages > UINT64_MAX / EFI_PAGE_SIZE)
            continue;
        UINT64 bytes = entry->NumberOfPages * EFI_PAGE_SIZE;
        if (address >= entry->PhysicalStart && address - entry->PhysicalStart < bytes &&
            size <= bytes - (address - entry->PhysicalStart))
            return true;
    }
    return false;
}

static bool checksum_valid(const UINT8 *data, UINTN size)
{
    UINT8 sum = 0;
    for (UINTN i = 0; i < size; i++)
        sum += data[i];
    return sum == 0;
}

static bool firmware_is_dave(void)
{
    VOID *entry = NULL;
    UINT64 address, size;
    UINT16 count = 0;
    UINTN entries, key, stride;
    UINT32 version;
    bool dave = false;
    bool smbios3 = !EFI_ERROR(LibGetSystemConfigurationTable(&SMBIOS3TableGuid, &entry));

    /* A present but malformed SMBIOS 3 table must not enable DAVE via SMBIOS 2. */
    if (!smbios3 && EFI_ERROR(LibGetSystemConfigurationTable(&SMBIOSTableGuid, &entry)))
        return false;
    EFI_MEMORY_DESCRIPTOR *map = LibMemoryMap(&entries, &key, &stride, &version);
    if (!map)
        return false;

    UINTN entry_size = smbios3 ? sizeof(SMBIOS3_STRUCTURE_TABLE) : sizeof(SMBIOS_STRUCTURE_TABLE);
    if (!readable_range(map, entries, stride, (UINTN)entry, entry_size))
        goto out;
    if (smbios3) {
        const SMBIOS3_STRUCTURE_TABLE *table = entry;
        if (CompareMem(table->AnchorString, "_SM3_", 5) ||
            table->EntryPointLength != entry_size || !checksum_valid(entry, entry_size))
            goto out;
        address = table->TableAddress;
        size = table->TableMaximumSize;
    } else {
        const SMBIOS_STRUCTURE_TABLE *table = entry;
        if (CompareMem(table->AnchorString, "_SM_", 4) ||
            table->EntryPointLength != entry_size || !checksum_valid(entry, entry_size) ||
            CompareMem(table->IntermediateAnchorString, "_DMI_", 5) ||
            !checksum_valid((const UINT8 *)entry + 16, 15) || !table->NumberOfSmbiosStructures)
            goto out;
        address = table->TableAddress;
        size = table->TableLength;
        count = table->NumberOfSmbiosStructures;
    }
    if (size <= MAX_SMBIOS_SIZE && readable_range(map, entries, stride, address, size))
        dave = smbios_is_dave((const UINT8 *)(UINTN)address, size, count);
out:
    FreePool(map);
    return dave;
}

/* GNU-EFI's crt0 calls efi_main using the native C ABI. */
EFI_STATUS efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *system)
{
    EFI_LOADED_IMAGE *loaded = NULL;
    EFI_HANDLE child = NULL;
    EFI_STATUS status;

    InitializeLib(image, system);
    status = uefi_call_wrapper(BS->HandleProtocol, 3, image, &LoadedImageProtocol, (VOID **)&loaded);
    if (EFI_ERROR(status))
        return status;
    if (!loaded || !loaded->DeviceHandle)
        return EFI_NOT_FOUND;
    /* FileDevicePath otherwise accepts a missing device path as a file-only path. */
    if (!DevicePathFromHandle(loaded->DeviceHandle))
        return EFI_NOT_FOUND;

    CHAR16 *target = firmware_is_dave() ? L"\\EFI\\Vale\\Dave.efi" : L"\\EFI\\Vale\\Normal.efi";
    EFI_DEVICE_PATH *path = FileDevicePath(loaded->DeviceHandle, target);
    if (!path)
        return EFI_OUT_OF_RESOURCES;
    status = uefi_call_wrapper(BS->LoadImage, 6, FALSE, image, path, NULL, 0, &child);
    FreePool(path);
    if (!EFI_ERROR(status))
        status = uefi_call_wrapper(BS->StartImage, 3, child, NULL, NULL);
    /* LoadImage can return an image handle even when authentication fails. */
    if (child)
        uefi_call_wrapper(BS->UnloadImage, 1, child);
    Print(L"Vale recovery: %s returned: %r\n", target, status);
    return status;
}
