/* SPDX-License-Identifier: MIT */
#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* SMBIOS 2 supplies a record count; SMBIOS 3 uses its end-of-table record. */
bool smbios_is_dave(const uint8_t *table, size_t size, uint16_t count);
