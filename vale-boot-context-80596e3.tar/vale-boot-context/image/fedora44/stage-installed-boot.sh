#!/usr/bin/env bash
set -euo pipefail
[[ $# == 2 && -f $1 && -s $2 ]]
raw=$1 dave=$2
# The pinned layout puts its single ESP first. USR and its verity stay unchanged.
info=$(sgdisk -i 1 "$raw")
[[ $(awk '/Partition GUID code:/ {print $4}' <<< "$info") == C12A7328-F81F-11D2-BA4B-00A0C93EC93B ]]
sector=$(awk '/First sector:/ {print $3}' <<< "$info")
[[ $sector =~ ^[1-9][0-9]*$ ]]
esp=$raw@@$((sector * 512))
mcopy -o -i "$esp" "$dave" ::/EFI/Linux/
# Normal remains the default; the native Dave install selects its own UKI.
config=$(mktemp)
trap 'rm -f -- "$config"' EXIT
mtype -i "$esp" ::/loader/loader.conf | sed '/^default[[:space:]]/d' > "$config"
printf '
default elementary_*
' >> "$config"
mcopy -o -i "$esp" "$config" ::/loader/loader.conf
