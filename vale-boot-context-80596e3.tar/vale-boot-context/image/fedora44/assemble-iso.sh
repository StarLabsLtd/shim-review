#!/usr/bin/env bash
set -euo pipefail

# Run inside mkosi's Fedora tools tree with the frozen native signing inputs.
: "${VALE_SECURE_BOOT_KEY:?set the Secure Boot private key}"
: "${VALE_SECURE_BOOT_CERT:?set the Secure Boot certificate}"
[[ $# -eq 1 ]]
worktree=$(realpath "$1")
version=$(cat "$worktree/mkosi.version")
[[ $version =~ ^[0-9]+$ ]]
cd "$worktree/mkosi.output"
live=liveiso_${version}
raw=elementary_${version}.raw
output=vale-fedora44-x86-64.${version}.iso
[[ ! -e $output ]]
work=$(mktemp -d .vale-iso.XXXXXX)
trap 'rm -rf "$work"' EXIT

[[ -d $live && -f $raw && -f vale-live.initrd && -f vale-live.vmlinuz ]]
install -d "$work/iso/live" "$work/iso/extra" "$work/raw"
"$worktree/stage-installed-boot.sh" "$raw" "elementary-dave_${version}.efi"
mksquashfs "$live" "$work/iso/live/filesystem.squashfs" -comp zstd -noappend
# The native backend consumes one raw image inside its existing squashfs capsule.
cp --reflink=auto "$raw" "$work/raw/$raw"
mksquashfs "$work/raw" "$work/iso/extra/${raw}.squashfs" -comp zstd -noappend
os_release=$live/usr/lib/os-release
kernel_version=$(cat vale-live.uname)
[[ $kernel_version == 7.2.8-vale3 ]]
xorriso -as mkisofs -iso-level 3 -volid "VALE_FEDORA44" \
    -output "${work}/source.iso" "${work}/iso"
truncate -s 512M "${work}/esp.img"
mkfs.vfat -n VALEINSTALL "${work}/esp.img"
mmd -i "${work}/esp.img" ::/EFI ::/EFI/BOOT
truncate -s 128M "${work}/verity.img"
printf 'Vale authenticated installer\n' > "${work}/marker"

make_layout() {
    unlink "${work}/candidate.iso" 2>/dev/null || true
    xorriso -indev "${work}/source.iso" -outdev "${work}/candidate.iso" \
        -map "${work}/marker" /VALE-SIGNED-USB \
        -boot_image any discard \
        -boot_image any system_area=/dev/zero \
        -boot_image any appended_part_as=gpt \
        -append_partition 2 0xef "${work}/esp.img" \
        -append_partition 3 0x83 "${work}/verity.img" \
        -boot_image any efi_path=--interval:appended_partition_2:all::
}

make_layout
partition_end=$(sgdisk -i 1 "${work}/candidate.iso" |
    awk '/Last sector:/ { print $3 }')
if (( (partition_end + 1) % 4 != 0 )); then
    truncate -s +2048 "${work}/marker"
    make_layout
    partition_end=$(sgdisk -i 1 "${work}/candidate.iso" |
        awk '/Last sector:/ { print $3 }')
fi
esp_start=$(sgdisk -i 2 "${work}/candidate.iso" |
    awk '/First sector:/ { print $3 }')
hash_start=$(sgdisk -i 3 "${work}/candidate.iso" |
    awk '/First sector:/ { print $3 }')
hash_partuuid=$(sgdisk -i 3 "${work}/candidate.iso" |
    awk '/Partition unique GUID:/ { print tolower($4) }')
[[ ${partition_end}${esp_start}${hash_start} =~ ^[0-9]+$ ]]
[[ ${hash_partuuid} =~ ^[0-9a-f-]{36}$ ]]
(( (partition_end + 1) % 4 == 0 && hash_start % 4 == 0 ))

data_blocks=$(((partition_end + 1) / 4))
hash_start_block=$((hash_start / 4))
salt=$(sha256sum "${raw}" | cut -d' ' -f1)
dd if="${work}/candidate.iso" of="${work}/data.img" bs=2048 \
    count="${data_blocks}" iflag=fullblock status=none
verity_output=$(veritysetup format --no-superblock \
    --data-block-size=2048 --hash-block-size=2048 --salt="${salt}" \
    "${work}/data.img" "${work}/verity.img")
root_hash=$(awk '/Root hash:/ { print $3 }' <<<"${verity_output}")
[[ ${root_hash} =~ ^[0-9a-f]{64}$ ]]
dd if="${work}/verity.img" of="${work}/candidate.iso" bs=512 \
    seek="${hash_start}" conv=notrunc status=none

stub="${live}/usr/lib/systemd/boot/efi/linuxx64.efi.stub"
[[ -s ${stub} ]]

cmdline="boot=vale-live root=live:/dev/mapper/vale-install-media live-media=/dev/mapper/vale-install-media rd.live.dir=live rd.live.squashimg=filesystem.squashfs rd.live.overlay.overlayfs=1 rd.live.overlay.readonly=1 ro rd.shell=0 rd.emergency=poweroff selinux=1 enforcing=1 systemd.swap=no panic=-1 quiet splash i915.force_probe=!7d51,!7d55 xe.force_probe=7d51,7d55 vale.media_data_blocks=${data_blocks} vale.media_hash_partuuid=${hash_partuuid} vale.media_hash_start_block=${hash_start_block} vale.media_root_hash=${root_hash} vale.media_salt=${salt}"
ukify=$(realpath ../.vale/bin/ukify.real)
[[ -f ${ukify} && -x ${ukify} ]]
verifier=$(realpath ../.vale/bin/verify-vale-uki.py)
sbat=$(realpath ../.vale/bin/sbat.vale.csv)
VALE_PCR_TOOLS=/usr/lib/systemd
: "${VALE_PCR_RECOVERY_KEY:?set the independent recovery signing key}"
: "${VALE_PCR_RECOVERY_CERT:?set the independent recovery certificate}"
: "${VALE_PCR_RECOVERY_PUBLIC_KEY:?set the independent recovery public key}"
# Check the pinned stock tools before ukify can select a fallback.
python3 - "${verifier}" "${ukify}" "${VALE_PCR_TOOLS}" "${stub}" "${sbat}" <<'PY_TOOLS'
import runpy
import sys
from pathlib import Path
v = runpy.run_path(sys.argv[1])
v["native_inputs"](*(Path(value) for value in sys.argv[2:]))
PY_TOOLS
for purpose in normal-recovery dave-recovery; do
    printf '%s' "${cmdline} vale.mode=${purpose}" > "${work}/${purpose}.cmdline"
    pcr=()
    public=()
    if [[ ${purpose} == dave-recovery ]]; then
        pcr=(--pcr-banks sha256 --pcrpkey "${VALE_PCR_RECOVERY_PUBLIC_KEY}"
             --pcr-private-key "${VALE_PCR_RECOVERY_KEY}"
             --pcr-certificate "${VALE_PCR_RECOVERY_CERT}" --phases sysinit:ready
             --tools "${VALE_PCR_TOOLS}")
        public=(--recovery-key "${VALE_PCR_RECOVERY_PUBLIC_KEY}"
                --runtime-key "${VALE_PCR_POLICY_PUBLIC_KEY}"
                --initrd-key "${VALE_PCR_INITRD_PUBLIC_KEY}")
    fi
    "${ukify}" build --stub "${stub}" --sbat "@${sbat}" \
        --linux vale-live.vmlinuz --initrd vale-live.initrd --no-sign-kernel \
        --os-release "@${os_release}" --uname "${kernel_version}" \
        --cmdline "@${work}/${purpose}.cmdline" "${pcr[@]}" \
        --secureboot-private-key "${VALE_SECURE_BOOT_KEY}" \
        --secureboot-certificate "${VALE_SECURE_BOOT_CERT}" \
        --output "${work}/${purpose}.efi"
    "${verifier}" "${work}/${purpose}.efi" --purpose "${purpose}" \
        --cmdline "${work}/${purpose}.cmdline" --sb-cert "${VALE_SECURE_BOOT_CERT}" \
        "${public[@]}"
done
# The parent's signed public dispatch uses the literal BIOS vendor admission.
: "${VALE_RECOVERY_DISPATCH:?set the reviewed signed firmware-selected recovery dispatch}"
sbverify --cert "$VALE_SECURE_BOOT_CERT" "$VALE_RECOVERY_DISPATCH"
mmd -i "$work/candidate.iso@@$((esp_start * 512))" ::/EFI/Vale
mcopy -o -i "$work/candidate.iso@@$((esp_start * 512))" \
    "$work/dave-recovery.efi" ::/EFI/Vale/Dave.efi
mcopy -o -i "$work/candidate.iso@@$((esp_start * 512))" \
    "$work/normal-recovery.efi" ::/EFI/Vale/Normal.efi
mcopy -o -i "$work/candidate.iso@@$((esp_start * 512))" \
    "$VALE_RECOVERY_DISPATCH" ::/EFI/BOOT/BOOTX64.EFI
openssl x509 -in "${VALE_SECURE_BOOT_CERT}" -outform DER \
    -out "${work}/vale-secure-boot.cer"
mcopy -o -i "${work}/candidate.iso@@$((esp_start * 512))" \
    "${work}/vale-secure-boot.cer" ::/vale-secure-boot.cer

mv -T "${work}/candidate.iso" "${output}"
sha256sum "${output}"
