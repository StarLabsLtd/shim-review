#!/usr/bin/env python3
"""Verify one explicit Vale UKI purpose using approved public build inputs."""

import argparse
import base64
import hashlib
import json
import os
import stat
import re
import struct
import subprocess
import tempfile
from pathlib import Path

ORDER = ".linux .osrel .cmdline .initrd .ucode .splash .dtb .uname .sbat .pcrpkey .profile .dtbauto .hwids .efifw".split()
RUNTIME = [
    "enter-initrd:leave-initrd",
    "enter-initrd:leave-initrd:sysinit",
    "enter-initrd:leave-initrd:sysinit:ready",
]
FILTER = "usr=elementary_*:usr-verity=elementary_*:usr-verity-sig=elementary_*:root=elementary-root:home=elementary-home"
POLICY = "esp=unprotected:xbootldr=unprotected+unused+absent:usr=signed:root=unprotected+encrypted:home=unprotected+absent:=ignore"
MAX_IMAGE = 512 * 1024 * 1024


def sha(data):
    return hashlib.sha256(data).digest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path, limit):
    require(path.is_file(), "not a regular file: " + str(path))
    with path.open("rb") as f:
        require(
            stat.S_ISREG(os.fstat(f.fileno()).st_mode),
            "not a regular file: " + str(path),
        )
        data = f.read(limit + 1)
    require(len(data) <= limit, "input exceeds bound: " + str(path))
    return data


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON member: " + key)
        result[key] = value
    return result


def bad_constant(value):
    raise ValueError("nonfinite JSON: " + value)


def load_json(data):
    return json.loads(
        data, object_pairs_hook=unique_object, parse_constant=bad_constant
    )


def sections(image):
    require(len(image) >= 64 and image[:2] == b"MZ", "invalid DOS header")
    p = struct.unpack_from("<I", image, 60)[0]
    require(
        p >= 64 and p + 24 <= len(image) and image[p : p + 4] == b"PE\0\0",
        "invalid PE header",
    )
    machine, count = struct.unpack_from("<HH", image, p + 4)
    optional = struct.unpack_from("<H", image, p + 20)[0]
    table = p + 24 + optional
    require(
        machine == 0x8664
        and 0 < count <= 96
        and optional >= 112
        and table + 40 * count <= len(image),
        "invalid x86-64 section table",
    )
    require(struct.unpack_from("<H", image, p + 24)[0] == 0x20B, "not PE32+")
    size, headers = struct.unpack_from("<II", image, p + 24 + 56)
    require(
        headers >= table + 40 * count
        and headers <= len(image)
        and headers <= size <= MAX_IMAGE,
        "invalid PE image bounds",
    )
    require(
        struct.unpack_from("<H", image, p + 24 + 68)[0] == 10, "not EFI application"
    )
    result, raw_ranges, memory_ranges = {}, [], []
    for i in range(count):
        h = table + 40 * i
        name_field = image[h : h + 8]
        name = name_field.split(b"\0", 1)[0].decode("ascii")
        require(
            name and name_field == name.encode().ljust(8, b"\0"),
            "invalid PE section name",
        )
        require(name not in result, "duplicate PE section: " + name)
        v, address, raw_size, offset = struct.unpack_from("<IIII", image, h + 8)
        require(
            v <= MAX_IMAGE
            and address >= headers
            and address + max(v, raw_size) <= size,
            "section outside image: " + name,
        )
        if raw_size:
            require(
                offset >= headers and offset + raw_size <= len(image),
                "section outside file: " + name,
            )
            require(
                all(offset + raw_size <= a or offset >= z for a, z in raw_ranges),
                "overlapping raw sections",
            )
            raw_ranges.append((offset, offset + raw_size))
        if max(v, raw_size):
            require(
                all(
                    address + max(v, raw_size) <= a or address >= z
                    for a, z in memory_ranges
                ),
                "overlapping loaded sections",
            )
            memory_ranges.append((address, address + max(v, raw_size)))
        # Native259.5 stub measures VirtualSize, including loader zero-fill; zero-size is absent.
        result[name] = image[offset : offset + min(v, raw_size)] + bytes(
            max(0, v - raw_size)
        )
    require(".profile" not in result, "profiles forbidden")
    require(
        not set(result) & {".dtbauto", ".hwids", ".efifw"},
        "hardware-selected sections unsupported",
    )
    require(
        all(
            result.get(n) for n in [".linux", ".initrd", ".osrel", ".uname", ".cmdline"]
        ),
        "missing UKI payload section",
    )
    for name, limit in [(".cmdline", 65536), (".pcrsig", 65536), (".pcrpkey", 8192)]:
        require(
            len(result.get(name, b"")) <= limit, "oversized metadata section: " + name
        )
    return result


def command_line(data, purpose, approved):
    payload = data.rstrip(b"\0")
    # The x86 kernel retains at most 2047 command-line bytes plus its NUL.
    require(len(payload) < 2048, "command line exceeds kernel input limit")
    value = payload.decode("utf-8")
    require(
        "\0" not in value and value == approved,
        "command line differs from approved input",
    )
    require(
        value.isascii()
        and not any(ord(c) < 0x20 or ord(c) == 0x7f for c in value)
        and not any(c in value for c in "\"'"),
        "nonliteral command line unsupported",
    )
    words = value.split()
    selectors = (
        "vale.mode",
        "root",
        "mount.usr",
        "systemd.image_filter",
        "systemd.image_policy",
    )
    live = {
        "root": "live:/dev/mapper/vale-install-media",
        "rd.live.dir": "live",
        "rd.live.squashimg": "filesystem.squashfs",
        "rd.live.overlay.overlayfs": "1",
        "rd.live.overlay.readonly": "1",
        "systemd.swap": "no",
        "rd.shell": "0",
        "rd.emergency": "poweroff",
        "selinux": "1",
        "enforcing": "1",
    }
    known = selectors + (
        "boot",
        "live-media",
        "vale.media_data_blocks",
        "vale.media_hash_partuuid",
        "vale.media_hash_start_block",
        "vale.media_root_hash",
        "vale.media_salt",
    ) + tuple(live)
    for word in words:
        key = word.split("=", 1)[0]
        require(
            all(
                key == k or key.replace("-", "_") != k.replace("-", "_") for k in known
            ),
            "noncanonical selector alias: " + key,
        )

    def values(key):
        return [
            w.split("=", 1)[1] if "=" in w else None
            for w in words
            if w.split("=", 1)[0] == key
        ]

    for key in selectors:
        require(len(values(key)) <= 1, "duplicate selector: " + key)
    mode = {
        "normal": [],
        "dave": ["dave"],
        "normal-recovery": ["normal-recovery"],
        "dave-recovery": ["dave-recovery"],
    }[purpose]
    require(values("vale.mode") == mode, "wrong signed purpose")
    if purpose in ("normal", "dave"):
        require(
            values("root") == ["dissect"] and values("mount.usr") == ["dissect"],
            "wrong installed root arguments",
        )
        wanted_filter, wanted_policy = FILTER, POLICY
        if purpose == "dave":
            wanted_filter = FILTER.replace(
                "root=elementary-root:", "root=elementary-root-dave:"
            )
            wanted_policy = POLICY.replace("root=unprotected+encrypted:", "root=encrypted:")
        require(values("systemd.image_filter") == [wanted_filter], "wrong root filter")
        require(values("systemd.image_policy") == [wanted_policy], "wrong root policy")
    else:
        fedora = values("boot") == ["vale-live"]
        require(
            all(not values(k) for k in selectors[2:])
            and (values("root") == [live["root"]] if fedora else not values("root")),
            "installed root selector in recovery",
        )
        require(
            (fedora or values("boot") == ["casper"])
            and values("live-media") == ["/dev/mapper/vale-install-media"],
            "wrong recovery medium",
        )
        if fedora:
            # Recovery has one producer. Extra boot arguments can override its
            # shell, overlay, LSM or swap policy before authenticated admission.
            optional = {
                "panic": "-1",
                "i915.force_probe": "!7d51,!7d55",
                "xe.force_probe": "7d51,7d55",
            }
            allowed = set(known) | set(optional) | {"ro", "quiet", "splash"}
            for word in words:
                require(word.split("=", 1)[0] in allowed,
                        "unapproved recovery argument: " + word)
            for key, expected in optional.items():
                require(values(key) in ([], [expected]),
                        "wrong recovery parameter: " + key)
            for flag in ("quiet", "splash"):
                require(values(flag) in ([], [None]),
                        "invalid recovery flag: " + flag)
            for key, expected in live.items():
                require(values(key) == [expected], "wrong live parameter: " + key)
            require(values("ro") == [None], "writable live root")
        for key in [
            "vale.media_data_blocks",
            "vale.media_hash_partuuid",
            "vale.media_hash_start_block",
            "vale.media_root_hash",
            "vale.media_salt",
        ]:
            require(
                len(values(key)) == 1 and bool(values(key)[0]),
                "missing/duplicate verified-medium parameter: " + key,
            )
    return value


def native_inputs(ukify, tools, stub, sbat):
    lock = Path(__file__).with_name("ukify.lock")
    if not lock.is_file():
        lock = Path(__file__).resolve().parents[1] / "elementary/ukify/upstream.lock"
    pins = dict(line.split("=", 1) for line in read(lock, 8192).decode().splitlines())
    for path, pin in [(ukify, "tool_sha256"),
                      (tools / "systemd-measure", "measure_sha256"),
                      (stub, "stub_sha256"), (sbat, "sbat_sha256")]:
        require(sha(read(path, MAX_IMAGE)).hex() == pins[pin],
                "unapproved native signing input: " + str(path))
    for path in (ukify, tools / "systemd-measure"):
        require(os.access(path, os.X_OK), "native tool is not executable: " + str(path))


def origin(args):
    return bytes(32), "stock-zero"


def run(*argv):
    return subprocess.check_output(
        list(map(str, argv)), stderr=subprocess.STDOUT, timeout=30
    )


def verify(args):
    image = read(args.uki, MAX_IMAGE)
    measured = sections(image)
    approved = read(args.cmdline, 65536).decode("utf-8").rstrip("\n")
    command_line(measured[".cmdline"], args.purpose, approved)
    pcr, prefix_status = origin(args)
    transcript = []
    for name in ORDER:
        data = measured.get(name, b"")
        if data:
            for label, digest in [
                (name + ":name-NUL", sha(name.encode() + b"\0")),
                (name + ":content", sha(data)),
            ]:
                pcr = sha(pcr + digest)
                transcript.append(
                    {"label": label, "digest": digest.hex(), "after": pcr.hex()}
                )
    if args.scratch is not None:
        args.scratch.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=args.scratch) as tmp:
        t = Path(tmp)
        (t / "uki.efi").write_bytes(image)
        (t / "sb.crt").write_bytes(read(args.sb_cert, 65536))
        run("sbverify", "--cert", t / "sb.crt", t / "uki.efi")
        groups = {
            "normal": {},
            "dave": {"runtime": ["enter-initrd", *RUNTIME], "initrd": ["enter-initrd"]},
            "normal-recovery": {},
            "dave-recovery": {"recovery": ["sysinit:ready"]},
        }[args.purpose]
        fingerprints = {}
        for role in (["runtime", "initrd", "recovery"] if groups else []):
            require(
                getattr(args, role + "_key") is not None,
                "missing approved " + role + " key",
            )
            (t / (role + ".pub")).write_bytes(read(getattr(args, role + "_key"), 8192))
            der = subprocess.check_output(
                [
                    "openssl",
                    "rsa",
                    "-pubin",
                    "-in",
                    str(t / (role + ".pub")),
                    "-RSAPublicKey_out",
                    "-outform",
                    "DER",
                ],
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
            fingerprints[role] = sha(der).hex()
        require(
            len(set(fingerprints.values())) == len(fingerprints),
            "PCR authorities must be distinct",
        )
        embedded = "runtime" if args.purpose in ("normal", "dave") else "recovery"
        if not groups:
            require(
                ".pcrsig" not in measured and ".pcrpkey" not in measured,
                "Normal image contains TPM policy authorities",
            )
            return {
                "purpose": args.purpose,
                "image_sha256": sha(image).hex(),
                "result": "PASS",
                "scope": "software-only, no DVH signatures",
            }
        require(
            measured.get(".pcrpkey", b"").rstrip(b"\0")
            == (t / (embedded + ".pub")).read_bytes().rstrip(b"\0"),
            "wrong embedded PCR key",
        )
        signatures = load_json(measured[".pcrsig"].rstrip(b"\0"))
        require(
            type(signatures) is dict
            and set(signatures) == {"sha256"}
            and type(signatures["sha256"]) is list,
            "unexpected PCR banks",
        )
        expected = {}
        for role, phases in groups.items():
            for phase in phases:
                phased = pcr
                for word in phase.split(":"):
                    phased = sha(phased + sha(word.encode()))
                policy = sha(
                    bytes(32)
                    + struct.pack(">I", 0x17F)
                    + bytes.fromhex("00000001000b03000800")
                    + sha(phased)
                )
                expected[(fingerprints[role], policy.hex())] = (
                    role,
                    phase,
                    phased.hex(),
                )
        require(
            len(signatures["sha256"]) == len(expected), "wrong authority/phase count"
        )
        results, seen = [], set()
        for entry in signatures["sha256"]:
            require(
                type(entry) is dict and set(entry) == {"pcrs", "pkfp", "pol", "sig"},
                "invalid signature entry",
            )
            require(
                entry["pcrs"] == [11] and type(entry["pcrs"][0]) is int,
                "signature must select PCR11 only",
            )
            require(
                type(entry["pkfp"]) is str
                and type(entry["pol"]) is str
                and re.fullmatch("[0-9a-f]{64}", entry["pkfp"])
                and re.fullmatch("[0-9a-f]{64}", entry["pol"]),
                "malformed authority/policy",
            )
            key = (entry["pkfp"], entry["pol"])
            require(
                key not in seen and key in expected,
                "duplicate or unexpected authority/phase policy",
            )
            seen.add(key)
            role, phase, phased = expected[key]
            require(
                type(entry["sig"]) is str and len(entry["sig"]) <= 2048,
                "malformed RSA signature",
            )
            signature = base64.b64decode(entry["sig"], validate=True)
            require(
                base64.b64encode(signature).decode() == entry["sig"],
                "noncanonical signature encoding",
            )
            (t / "policy.bin").write_bytes(bytes.fromhex(entry["pol"]))
            (t / "signature.bin").write_bytes(signature)
            run(
                "openssl",
                "dgst",
                "-sha256",
                "-verify",
                t / (role + ".pub"),
                "-signature",
                t / "signature.bin",
                t / "policy.bin",
            )
            results.append(
                {
                    "authority": role,
                    "phase": phase,
                    "pcr11": phased,
                    "policy": entry["pol"],
                }
            )
        return {
            "purpose": args.purpose,
            "image_sha256": sha(image).hex(),
            "prefix_status": prefix_status,
            "transcript": transcript,
            "policies": results,
            "result": "PASS",
            "scope": "software-only; no boot/firmware/TPM acceptance",
        }


def main():
    p = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    p.add_argument("uki", type=Path)
    p.add_argument(
        "--purpose",
        required=True,
        choices=["normal", "dave", "normal-recovery", "dave-recovery"],
    )
    for option in ["sb-cert", "cmdline"]:
        p.add_argument("--" + option, required=True, type=Path)
    for option in ["runtime-key", "initrd-key", "recovery-key"]:
        p.add_argument("--" + option, type=Path)
    p.add_argument("--scratch", type=Path, default=None)
    args = p.parse_args()
    try:
        print(json.dumps(verify(args), indent=2))
    except (
        ValueError,
        KeyError,
        TypeError,
        UnicodeError,
        RecursionError,
        struct.error,
        OSError,
        subprocess.SubprocessError,
    ) as e:
        p.exit(1, "UKI refused: " + str(e) + "\n")


if __name__ == "__main__":
    main()
