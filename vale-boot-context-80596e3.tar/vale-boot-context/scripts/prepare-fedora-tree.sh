#!/usr/bin/env bash
set -euo pipefail

repo_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
worktree=${repo_root}/work/fedora44
rpm_directory=${VALE_RPM_DIRECTORY:-${repo_root}/out/rpms/fedora-44}
: "${VALE_FEDORA_UKIFY_LOCK:?set the approved Fedora native signing-tool lock}"
: "${VALE_FEDORA_UKIFY:?set the pinned Fedora ukify executable}"
: "${VALE_UPDATE_PUBLIC_KEY:?set VALE_UPDATE_PUBLIC_KEY to the public sysupdate key}"
[[ $# -eq 1 && $1 =~ ^[0-9]+$ ]] || {
    echo "usage: $0 VERSION" >&2
    exit 2
}
[[ ! -e $worktree ]] || {
    echo "Use a fresh work/fedora44 directory for a new package cohort." >&2
    exit 1
}
command -v rpm >/dev/null
mapfile -t fingerprints < <(gpg --batch --with-colons --show-keys "$VALE_UPDATE_PUBLIC_KEY" |
    awk -F: '$1 == "pub" { primary=1; next } primary && $1 == "fpr" { print $10; primary=0 }')
[[ ${#fingerprints[@]} -eq 1 && ${fingerprints[0]} =~ ^[0-9A-F]{40}$ ]]

stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
cp -a "${repo_root}/image/fedora44/." "$stage/"
install -d "$stage/mkosi.packages"
declare -A packages=()
while IFS= read -r -d '' package; do
    [[ $(rpm -qp --qf '%{SOURCEPACKAGE}' "$package") != 1 ]] || continue
    identity=$(rpm -qp --qf '%{NAME} %{ARCH} %{EPOCHNUM}:%{VERSION}-%{RELEASE}' "$package")
    read -r name architecture evr <<< "$identity"
    [[ $name =~ ^[a-zA-Z0-9+_.-]+$ && $evr =~ ^[a-zA-Z0-9:+_.~^-]+$ ]]
    case $architecture in
        src|nosrc) continue ;;
        x86_64|noarch) ;;
        *) echo "Unexpected RPM architecture: $identity" >&2; exit 1 ;;
    esac
    rpm --checksig --nosignature "$package" >&2
    [[ -z ${packages[$name]+present} ]] || {
        echo "More than one local RPM for $name; freeze one cohort." >&2
        exit 1
    }
    packages[$name]=$evr
    install -m 0644 "$package" "$stage/mkosi.packages/"
    printf '%s\n' "$identity" >> "$stage/rpm-nevra.txt"
done < <(find "$rpm_directory" -type f -name '*.rpm' -print0 | sort -z)
while IFS= read -r name; do
    [[ -n ${packages[$name]:-} ]] || {
        echo "Missing local runtime RPM: $name" >&2
        exit 1
    }
done < "$stage/local-packages.list"
(
    cd "$stage/mkosi.packages"
    sha256sum -- *.rpm > ../rpm-sha256.txt
)
# These public authorities are consumed by installed ROOT and HIB helpers.
base_keys=$stage/mkosi.images/base/mkosi.extra/usr/lib/vale
initrd_keys=$stage/mkosi.images/vale-initrd/mkosi.extra/usr/lib/vale
install -d "$base_keys/hibernate-storage" "$initrd_keys/hibernate-storage-initrd"
for role in policy initrd recovery; do
    case $role in
        policy) key=${VALE_PCR_POLICY_PUBLIC_KEY:?set the runtime PCR public key} ;;
        initrd) key=${VALE_PCR_INITRD_PUBLIC_KEY:?set the initrd PCR public key} ;;
        recovery) key=${VALE_PCR_RECOVERY_PUBLIC_KEY:?set the recovery PCR public key} ;;
    esac
    openssl pkey -pubin -in "$key" -noout
    if [[ $role != recovery ]]; then
        install -m 0644 "$key" "$base_keys/pcr-$role-public-key.pem"
    fi
    install -m 0644 "$key" "$base_keys/hibernate-storage/pcr-$role-public-key.pem"
    install -m 0644 "$key" "$initrd_keys/hibernate-storage-initrd/pcr-$role-public-key.pem"
done
install -d "$stage/.vale/bin"
for helper in verify-vale-uki.py build-vale-dave-uki.py; do
    install -m 0755 "${repo_root}/scripts/$helper" "$stage/.vale/bin/$helper"
done
install -m 0755 "${repo_root}/scripts/ukify-with-vale-pcr" "$stage/.vale/bin/ukify"
install -m 0755 "$VALE_FEDORA_UKIFY" "$stage/.vale/bin/ukify.real"
install -m 0644 "$VALE_FEDORA_UKIFY_LOCK" "$stage/.vale/bin/ukify.lock"
install -m 0644 "${repo_root}/elementary/ukify/sbat.vale.csv" "$stage/.vale/bin/sbat.vale.csv"
ukify_sha256=$(sed -n 's/^tool_sha256=//p' "$VALE_FEDORA_UKIFY_LOCK")
[[ $ukify_sha256 =~ ^[0-9a-f]{64}$ ]]
printf '%s  %s\n' "$ukify_sha256" "$stage/.vale/bin/ukify.real" | sha256sum --check >&2
printf '\n[Build]\nExtraSearchPaths=%%D/.vale/bin\nToolsTreePackageDirectories=%%D/mkosi.packages\nToolsTreePackages=\n    systemd-ukify-%s\n    systemd-boot-unsigned-%s\n    systemd-udev-%s\n' \
    "${packages[systemd-ukify]}" "${packages[systemd-boot-unsigned]}" "${packages[systemd-udev]}" >> "$stage/mkosi.conf"
printf '%s\n' "$1" > "$stage/mkosi.version"
transfer_dir=$stage/mkosi.images/base/mkosi.extra/usr/lib/sysupdate.d
install -d "$transfer_dir" "$stage/mkosi.images/base/mkosi.extra/usr/lib/systemd"
install -m 0644 "$stage"/sysupdate.d/*.transfer "$transfer_dir/"
install -m 0644 "$VALE_UPDATE_PUBLIC_KEY" \
    "$stage/mkosi.images/base/mkosi.extra/usr/lib/systemd/import-pubring.pgp"
dave_transfer=$stage/mkosi.images/base/mkosi.extra/usr/lib/vale/secure-owner
install -d "$dave_transfer"
install -m 0644 "$stage/sysupdate-dave/20-uki.transfer" "$dave_transfer/20-dave-uki.transfer"
mkdir -p "${repo_root}/work"
mv "$stage" "$worktree"
trap - EXIT
printf '%s\n' "$worktree"
