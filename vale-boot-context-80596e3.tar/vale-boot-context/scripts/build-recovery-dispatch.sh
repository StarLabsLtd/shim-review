#!/usr/bin/env bash
set -euo pipefail
repo=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
output=${1:?usage: build-recovery-dispatch.sh OUTPUT_DIRECTORY}
mkdir -p "${output}"
output=$(realpath "${output}")
sdk=$(podman image inspect localhost/vale-shim:16.1 --format '{{.Id}}')
printf '%s\n' "${sdk}" > "${output}/sdk-image-id"
podman run --rm -i --pull=never --network none --read-only --cap-drop all \
    --security-opt no-new-privileges --tmpfs /tmp:rw,nosuid,nodev \
    -v "${repo}/elementary/installer/recovery-dispatch:/source:ro" \
    -v "${output}:/output:rw" "${sdk}" bash -s <<'BUILD'
set -euo pipefail
cd /output
efi=/build/gnu-efi
flags=(-std=c11 -DGNU_EFI_USE_MS_ABI -I "$efi/inc" -I "$efi/inc/x86_64"
       -Wall -Wextra -Werror -fshort-wchar -mno-red-zone -maccumulate-outgoing-args)
gcc "${flags[@]}" -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer \
    /source/test-dispatch.c /source/dispatch.c /source/smbios.c -o test-dispatch
./test-dispatch
for unit in dispatch smbios; do
    gcc "${flags[@]}" -O2 -fpic -ffreestanding -fno-stack-protector \
        -fno-strict-aliasing -fno-asynchronous-unwind-tables \
        -c "/source/$unit.c" -o "$unit.o"
done
ld -nostdlib -znocombreloc --build-id=none -T "$efi/gnuefi/elf_x86_64_efi.lds" \
    -shared -Bsymbolic "$efi/x86_64/gnuefi/crt0-efi-x86_64.o" dispatch.o smbios.o \
    /build/lib/string.o \
    -L "$efi/x86_64/lib" -L "$efi/x86_64/gnuefi" -lefi -lgnuefi \
    -o recovery-dispatch.so
if nm -u recovery-dispatch.so | grep .; then
    echo 'Unresolved EFI symbols' >&2
    exit 1
fi
objcopy -j .text -j .sdata -j .data -j .rodata -j .sbat -j .dynamic -j .dynsym \
    -j .rel -j .rela -j .reloc --strip-all -O pei-x86-64 --subsystem=10 \
    recovery-dispatch.so recovery-dispatch.efi
/build/post-process-pe -n -x recovery-dispatch.efi
objdump -p recovery-dispatch.efi
sha256sum recovery-dispatch.efi
BUILD
