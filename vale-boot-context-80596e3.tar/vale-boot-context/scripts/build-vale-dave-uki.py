#!/usr/bin/env python3
"""Derive one installed DAVE UKI from verified Normal inputs; no root/ESP writes."""

import argparse
import os
import runpy
import subprocess
import tempfile
from pathlib import Path


def required(name):
    value = os.environ.get(name)
    if not value:
        raise ValueError("missing approved build input: " + name)
    return value


def run(*args):
    subprocess.run(list(map(str, args)), check=True)


def main():
    p = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    p.add_argument("--purpose", required=True, choices=["dave"])
    for option in [
        "normal",
        "normal-cmdline",
        "cmdline",
        "output",
        "stub",
        "sbat",
        "ukify",
        "tools",
    ]:
        p.add_argument("--" + option, type=Path, required=True)
    a = p.parse_args()
    verifier = Path(__file__).with_name("verify-vale-uki.py")
    v = runpy.run_path(str(verifier))
    public = {
        "sb_cert": Path(required("VALE_SECURE_BOOT_CERT")),
        "runtime_key": Path(required("VALE_PCR_POLICY_PUBLIC_KEY")),
        "initrd_key": Path(required("VALE_PCR_INITRD_PUBLIC_KEY")),
        "recovery_key": Path(required("VALE_PCR_RECOVERY_PUBLIC_KEY")),
    }
    normal = argparse.Namespace(
        uki=a.normal,
        purpose="normal",
        cmdline=a.normal_cmdline,
        sb_cert=public["sb_cert"],
        runtime_key=public["runtime_key"],
        initrd_key=None,
        recovery_key=None,
        scratch=None,
    )
    v["verify"](normal)
    sections = v["sections"](v["read"](a.normal, v["MAX_IMAGE"]))
    cmd = v["read"](a.normal_cmdline, 65536).decode().rstrip("\n")
    cmd = cmd.replace(
        "systemd.image_filter=" + v["FILTER"],
        "systemd.image_filter="
        + v["FILTER"].replace("root=elementary-root:", "root=elementary-root-dave:"),
    )
    cmd = (
        cmd.replace(
            "systemd.image_policy=" + v["POLICY"],
            "systemd.image_policy="
            + v["POLICY"].replace("root=unprotected+encrypted:", "root=encrypted:"),
        )
        + " vale.mode=dave"
    )
    v["command_line"](cmd.encode(), a.purpose, cmd)
    a.cmdline.write_text(cmd)
    v["native_inputs"](a.ukify, a.tools, a.stub, a.sbat)
    with tempfile.TemporaryDirectory() as tmp:
        t = Path(tmp)
        for name, data in sections.items():
            if name in v["ORDER"] and name not in (".pcrpkey", ".cmdline"):
                (t / name[1:]).write_bytes(data)
        run("sbverify", "--cert", public["sb_cert"], t / "linux")
        args = [
            a.ukify,
            "build",
            "--stub",
            a.stub,
            "--linux",
            t / "linux",
            "--initrd",
            t / "initrd",
            "--os-release",
            "@" + str(t / "osrel"),
            "--uname",
            sections[".uname"].rstrip(b"\0").decode(),
            "--cmdline",
            "@" + str(a.cmdline),
            "--sbat",
            "@" + str(a.sbat),
            "--no-sign-kernel",
            "--pcr-banks",
            "sha256",
            "--pcrpkey",
            public["runtime_key"],
            "--pcr-private-key",
            required("VALE_PCR_POLICY_KEY"),
            "--pcr-certificate",
            required("VALE_PCR_POLICY_CERT"),
            "--phases",
            " ".join(["enter-initrd", *v["RUNTIME"]]),
            "--pcr-private-key",
            required("VALE_PCR_INITRD_KEY"),
            "--pcr-certificate",
            required("VALE_PCR_INITRD_CERT"),
            "--phases",
            "enter-initrd",
            "--tools",
            a.tools,
            "--secureboot-private-key",
            required("VALE_SECURE_BOOT_KEY"),
            "--secureboot-certificate",
            public["sb_cert"],
            "--output",
            a.output,
        ]
        for name, option in [
            (".ucode", "--microcode"),
            (".splash", "--splash"),
            (".dtb", "--devicetree"),
        ]:
            if sections.get(name):
                args += [option, t / name[1:]]
        run(*args)
    dave = argparse.Namespace(
        uki=a.output,
        purpose=a.purpose,
        cmdline=a.cmdline,
        **public,
        scratch=None,
    )
    v["verify"](dave)
    actual = v["sections"](v["read"](a.output, v["MAX_IMAGE"]))
    for name in v["ORDER"]:
        if name not in (".cmdline", ".pcrpkey"):
            v["require"](
                actual.get(name, b"") == sections.get(name, b""),
                "shared section drift: " + name,
            )
    print("Single-purpose installed DAVE UKI and shared payloads: PASS")


if __name__ == "__main__":
    try:
        main()
    except (
        ValueError,
        KeyError,
        TypeError,
        UnicodeError,
        OSError,
        subprocess.SubprocessError,
    ) as e:
        raise SystemExit("DAVE UKI build refused: " + str(e))
